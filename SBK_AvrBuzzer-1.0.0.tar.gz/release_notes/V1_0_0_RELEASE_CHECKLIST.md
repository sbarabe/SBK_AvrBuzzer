# Release checklist — SBK_AvrBuzzer 1.0.0

## Repository layout

Confirm the GitHub repository root contains:

- `library.properties`
- `library.json`
- `keywords.txt`
- `README.md`
- `CHANGELOG.md`
- `LICENSE`
- `src/SBK_AvrBuzzer.h`
- `src/SBK_AvrBuzzer.cpp`
- at least one valid sketch under `examples/<ExampleName>/<ExampleName>.ino`

## Validation

1. Compile every example for at least Arduino Uno and the intended ATmega328PB board package.
2. Install the repository ZIP through Arduino IDE's **Add .ZIP Library** and compile an example.
3. Run `pio pkg pack` from the repository root and inspect the generated archive.
4. Test a PlatformIO project with:

   ```ini
   lib_deps =
       sbarabe/SBK_AvrBuzzer@^1.0.0
   ```

## GitHub release

1. Commit the final `1.0.0` files.
2. Create an annotated tag named `v1.0.0` on that exact commit.
3. Create the GitHub release from `v1.0.0` and paste `RELEASE_NOTES.md` into the release description.

## Arduino Library Manager submission

After the public repository and `v1.0.0` tag exist, submit the repository URL to the Arduino Library Registry. The indexer reads tagged revisions, so all required files must already be correct in the tagged commit.

## PlatformIO Registry publication

Sign in to PlatformIO Core, then publish from the clean repository root:

```bash
pio account login
pio pkg pack
pio pkg publish
```

A published name/version pair cannot be reused, so publish only after the final validation succeeds.
